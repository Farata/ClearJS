java -cp hsqldb.jar org.hsqldb.util.ShutdownServer -url jdbc:hsqldb:hsql://localhost:9002/flexdemodb
java -cp hsqldb.jar org.hsqldb.util.ShutdownServer -url jdbc:hsqldb:hsql://localhost:9002/salesbuilderdb
java -cp hsqldb.jar org.hsqldb.util.ShutdownServer -url jdbc:hsqldb:hsql://localhost:9002/ordersdb
